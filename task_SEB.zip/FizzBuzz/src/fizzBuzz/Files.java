package fizzBuzz;

public interface Files {

}
